<?php
//Importar el model
require('../model/board-model.php');

//Crear la instancia del model
$objModelB = new Dashboard_model();

//Crear la variable post que recibira el tipo de accion requerida.
$action = $_POST['action'];

if ($action == "getUsers") {
    echo json_encode($objModelB->getDataFromApi("localhost:9000/api/Users"));
}