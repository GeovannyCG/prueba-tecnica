<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Inicio</title>
    <link rel="stylesheet" href="">
    <!-- link de CSS Local -->
    <link rel="stylesheet" type="text/css" href="../assets/css/board-style.css">
    <!-- link de CDN CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- link de CDN icons Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>

<body>

    <!-- Start Navbar -->
    <nav class="navbar" id="nav-main">
        <div class="container-fluid">
            <a class="navbar-brand" href="#../Dashboard/">
                <img src="../assets/images/logo.png" alt="Logo" width="30" height="24"
                    class="d-inline-block align-text-top">
                Prueba Tecnica
            </a>
        </div>
    </nav>
    <!-- End Navbar -->

    <!-- Start main -->
    <main>
        <!-- Div where stay table with the registrers-->
        <div>
            <h2>Tabla usuarios</h2>

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Email</th>
                        <th scope="col">Direccion</th>
                        <th scope="col">Telefono</th>
                        <th scope="col">Fecha de nacimiento</th>
                        <th scope="col">Edad</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody id="table-users">
                </tbody>
            </table>

        </div>

    </main>
    <!-- End Start main -->

    <!-- link de CDN JavaScript de bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <!-- CDN de jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <!-- CDN js propio -->
    <script src="../assets/js/board-app.js"></script>
</body>

</html>