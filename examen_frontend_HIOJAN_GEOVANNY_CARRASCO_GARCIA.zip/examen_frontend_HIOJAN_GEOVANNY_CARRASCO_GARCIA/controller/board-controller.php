<?php
require ("../model/board-model.php");

try {
    
    include ("../view/board-view.php");

} catch (\Throwable $th) {
    echo "<script>console.log('" . $th->getMessage() . "')</script>";
}