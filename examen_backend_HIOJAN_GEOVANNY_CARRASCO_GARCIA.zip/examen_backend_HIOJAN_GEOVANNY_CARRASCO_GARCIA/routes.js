// Importamos el módulo 'express', que es un framework web para Node.js
const express = require('express');

// Creamos un objeto 'Router' utilizando el método 'Router()' de Express
const routes = express.Router();

// Exportamos las rutas definidas para que puedan ser utilizadas por otros módulos
module.exports = routes;

//Ruta para obtener la informacion de todos los usuarios del usuario
routes.get('/Users', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.send(err);

        conn.query(`
            SELECT u.id_a, u.name_a, u.email_a, u.password_a, i.adress_ip, i.phone_ip, i.birthday_ip  
            FROM usuarios u JOIN informacion_personal i ON u.id_a = i.id_a
            `, (err, rows) => {
            if (err) return res.send(err);

            res.json(rows);
        });
    });
});

//Ruta para obtener la informacion de un usuario en especifico
routes.get('/User/:id', (req, res) => {
    req.getConnection((err, conn) => {
        if (err) return res.send(err);

        conn.query(`
            SELECT u.id_a, u.name_a, u.email_a, u.password_a, i.adress_ip, i.phone_ip, i.birthday_ip  
            FROM usuarios u JOIN informacion_personal i ON u.id_a = i.id_a WHERE u.id_a =?
            `, [req.params.id] ,(err, rows) => {
            if (err) return res.send(err);

            res.json(rows);
        });
    });
});

//Ruta para actualizar un registro de la base de datos
routes.put('/UpdateUser', (req, res) => {

    const { id, name, email, password, adress, phone, birthday } = req.body;

    req.getConnection((err, conn) => {
        if (err) return res.send(err);

        conn.beginTransaction((err) => {
            if (err) {
                res.status(500).json({ error: 'Error al iniciar la transaccion' });
                return;
            }

            const UpTbUsuarios = 'UPDATE usuarios SET name_a = ?, email_a = ?, password_a = ? WHERE id_a = ?';
            const upTbInfoPerso = 'UPDATE informacion_personal SET adress_ip = ?, phone_ip = ?, birthday_ip= ? WHERE id_a = ?'

            conn.query(UpTbUsuarios, [name, email, password, id], (err, results) => {
                if (err) {
                    return conn.rollback(() => {
                        res.status(500).json({ error: 'Error al actualizar en la tabla usuarios' });
                    });
                }

                conn.query(upTbInfoPerso, [adress, phone, birthday, id], (err, results) => {
                    if (err) {
                        return conn.rollback(() => {
                            res.status(500).json({ error: 'Error al Actualizar en la tabla informacion_personal' });
                        });
                    }

                    conn.commit((err) => {
                        if (err) {
                            return conn.rollback(() => {
                                res.status(500).json({ error: 'Error al realizar la transaccion' });
                            });
                        }
                        res.json({ message: 'Actualizacion correcta' });
                    });
                });
            });
        });


    });

});

//Ruta para eliminar un registro de la base de datos
routes.delete('/DeleteUser/:id', (req, res) => {

    req.getConnection((err, conn) => {
        if (err) return res.send(err);

        conn.beginTransaction((err) => {
            if (err) {
                res.status(500).json({ error: 'Error al iniciar la transaccion' });
                return;
            }

            const DelTbUsuarios = 'DELETE FROM usuarios WHERE id_a = ?';
            const DelTbInfoPerso = 'DELETE FROM informacion_personal WHERE id_a = ?'

            conn.query(DelTbInfoPerso, [req.params.id], (err, results) => {
                if (err) {
                    return conn.rollback(() => {
                        res.status(500).json({ error: 'Error al eliminar en la tabla informacion_personal' });
                    });
                }

                conn.query(DelTbUsuarios, [req.params.id], (err, results) => {
                    if (err) {
                        return conn.rollback(() => {
                            res.status(500).json({ error: 'Error al eliminar en la tabla usuario' });
                        });
                    }

                    conn.commit((err) => {
                        if (err) {
                            return conn.rollback(() => {
                                res.status(500).json({ error: 'Error al realizar la transaccion' });
                            });
                        }
                        res.json({ message: 'Eliminacion correcta' });
                    });
                });
            });
        });


    });

});