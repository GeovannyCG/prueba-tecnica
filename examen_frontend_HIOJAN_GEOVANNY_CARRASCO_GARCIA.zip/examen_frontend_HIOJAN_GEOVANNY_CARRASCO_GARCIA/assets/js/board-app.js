$(function () {

    let table = document.getElementById("table-users");

    //Funcion para calcular la edad del usuario
    function calcularEdad(birthday) {
        const today = new Date();
        const birthDate = new Date(birthday);
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDiff = today.getMonth() - birthDate.getMonth();

        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }

        return age;
    }

    //Funcion para extraer a todos los usuarios por medio de la API REST
    function getUsers() {
        $.ajax({
            type: "POST",
            url: "../dash-actions",
            data: { action: "getUsers" },
            dataType: "json",
            success: function (response) {
                // console.log(response);
                response.forEach((e) => {
                    let row = document.createElement("tr");
                    row.innerHTML = `
                        <td>${e["id_a"]}</td>
                        <td>${e["name_a"]}</td>
                        <td>${e["email_a"]}</td>
                        <td>${e["adress_ip"]}</td>
                        <td>${e["phone_ip"]}</td>
                        <td>${e["birthday_ip"]}</td>
                        <td>${calcularEdad(e["birthday_ip"])} años</td>
                        <td>
                            <a href="../EditUser/${e["id_a"]}" class="btn btn-warning"><i class="bi bi-pencil-square"></i></a>
                            <a href="../Delete/${e["id_a"]}" class="btn btn-danger"><i class="bi bi-trash3-fill"></i></a>
                        </td>
                    `;
                    table.appendChild(row);
                });
            }
        });
    }

    getUsers();

});
