<?php
// Importar el model
require('../model/edit-model.php');

try {
    $id = $_GET['id']; // Obtener el ID del elemento que deseamos extraer

    $objModelE = new Edit_model();
    $response = $objModelE->getUser($id);

    if ($response) {
        $datos = json_decode($response, true); // Decodificar la respuesta JSON como array asociativo
        include("../view/edit-view.php"); // Incluir la vista
    } else {
        // Manejar el caso de respuesta nula o error
        echo "Error al obtener los datos del usuario";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
