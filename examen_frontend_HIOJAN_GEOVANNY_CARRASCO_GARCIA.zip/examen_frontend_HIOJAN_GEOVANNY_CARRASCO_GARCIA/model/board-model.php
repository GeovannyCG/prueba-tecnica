<?php

class Dashboard_model
{

    public function __construct()
    {
    }

    // Función para obtener datos de la API REST
    public function getDataFromApi($apiUrl)
    {
        $ch = curl_init($apiUrl);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        if ($httpCode >= 200 && $httpCode < 300) {
            return json_decode($response, true); // Decode JSON directly to array
        } else {
            // Manejo de errores si fuera necesario
            return null;
        }
    }

    //Funcion para eliminar a un usuario
    public function deleteUser($id)
    {
        $curl = curl_init(); // Inicia la sesión cURL

        curl_setopt_array(
            $curl,
            array(
                CURLOPT_URL => "localhost:9000/api/DeleteUser/" . $id, // URL a la que se conecta
                CURLOPT_RETURNTRANSFER => true, // Devuelve el resultado como una cadena del tipo curl_exec
                CURLOPT_FOLLOWLOCATION => true, // Sigue el encabezado que le envíe el servidor
                CURLOPT_ENCODING => "", // Permite decodificar la respuesta y puede ser "identity", "deflate", y "gzip", si está vacío recibe todos los disponibles.
                CURLOPT_MAXREDIRS => 10, // Si usamos CURLOPT_FOLLOWLOCATION le dice el máximo de encabezados a seguir
                CURLOPT_TIMEOUT => 30, // Tiempo máximo para ejecutar
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, // Usa la versión declarada
                CURLOPT_CUSTOMREQUEST => "DELETE", // El tipo de petición, puede ser PUT, POST, GET o Delete dependiendo del servicio
                CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/json'
                ),
            )
        );

        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        curl_close($curl);

        if ($httpCode >= 200 && $httpCode < 300) {
            return json_decode($response, true); // Decode JSON directly to array
        } else {
            // Manejo de errores si fuera necesario
            return null;
        }
    }

}

