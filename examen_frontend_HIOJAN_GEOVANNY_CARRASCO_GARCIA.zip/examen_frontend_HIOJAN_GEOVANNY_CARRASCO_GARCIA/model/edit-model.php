<?php

class Edit_model
{

    public function __construct()
    {
    }

    // Función para obtener datos de la API REST
    public function getUser($id)
{
    $curl = curl_init(); // Inicia la sesión cURL

    curl_setopt_array(
        $curl,
        array(
            CURLOPT_URL => "localhost:9000/api/User/" . $id, // URL a la que se conecta
            CURLOPT_RETURNTRANSFER => true, // Devuelve el resultado como una cadena del tipo curl_exec
            CURLOPT_FOLLOWLOCATION => true, // Sigue el encabezado que le envíe el servidor
            CURLOPT_ENCODING => "", // Permite decodificar la respuesta y puede ser "identity", "deflate", y "gzip", si está vacío recibe todos los disponibles.
            CURLOPT_MAXREDIRS => 10, // Si usamos CURLOPT_FOLLOWLOCATION le dice el máximo de encabezados a seguir
            CURLOPT_TIMEOUT => 30, // Tiempo máximo para ejecutar
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, // Usa la versión declarada
            CURLOPT_CUSTOMREQUEST => "GET", // El tipo de petición, puede ser PUT, POST, GET o Delete dependiendo del servicio
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        )
    );

    $response = curl_exec($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

    curl_close($curl);

    if ($httpCode >= 200 && $httpCode < 300) {
        return $response; // Devuelve la respuesta como cadena JSON
    } else {
        // Manejo de errores si fuera necesario
        return null;
    }
}
    //Funcion para eliminar a un usuario
    public function UpdateUser($userData)
    {
        $curl = curl_init(); // Inicia la sesión cURL
    
        // URL del endpoint de actualización
        $url = "localhost:9000/api/UpdateUser/";
    
        // Convierte el arreglo de datos de usuario a formato JSON
        $jsonData = json_encode($userData);
    
        curl_setopt_array(
            $curl,
            array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "PUT", // Cambia a PUT para actualizar datos
                CURLOPT_POSTFIELDS => $jsonData, // Envía el cuerpo JSON
                CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($jsonData) // Añade la longitud del contenido
                ),
            )
        );
    
        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    
        curl_close($curl);
    
        if ($httpCode >= 200 && $httpCode < 300) {
            return json_decode($response, true); // Decodifica la respuesta JSON a un arreglo asociativo
        } else {
            // Manejo de errores si fuera necesario
            return null;
        }
    }

}

