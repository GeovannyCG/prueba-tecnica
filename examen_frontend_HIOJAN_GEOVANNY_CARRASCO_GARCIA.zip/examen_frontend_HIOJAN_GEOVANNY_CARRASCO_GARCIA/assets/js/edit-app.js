function validateForm() {
    const name = document.getElementById('inputName').value;
    const email = document.getElementById('inputEmail').value;
    const password = document.getElementById('inputPass').value;
    const address = document.getElementById('inputAdress').value;
    const phone = document.getElementById('inputNumber').value;
    const birthday = document.getElementById('inputBirthday').value;

    const nameRegex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{1,100}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    const passwordRegex = /^[a-zA-Z0-9!@#$%^&*()_+]{1,100}$/;
    const addressRegex = /^[a-zA-Z0-9\s,]{1,100}$/;
    const phoneRegex = /^[0-9]{10,10}$/;

    if (!nameRegex.test(name)) {
        alert('El nombre solo puede llevar caracteres alfabeticos.');
        return false;
    }

    if (!emailRegex.test(email)) {
        alert('Por favor, introduce una dirección de correo electrónico válida.');
        return false;
    }

    if (!passwordRegex.test(password)) {
        alert('La contraseña debe tener letras, números y caracteres especiales.');
        return false;
    }

    if (!addressRegex.test(address)) {
        alert('El nombre solo puede llevar caracteres alfanumericos y caracteres especiales.');
        return false;
    }

    if (!phoneRegex.test(phone)) {
        alert('El número de teléfono debe tener 10 digitos.');
        return false;
    }

    if (new Date(birthday) > new Date()) {
        alert('La fecha de nacimiento no puede ser en el futuro.');
        return false;
    }

    return true;
}