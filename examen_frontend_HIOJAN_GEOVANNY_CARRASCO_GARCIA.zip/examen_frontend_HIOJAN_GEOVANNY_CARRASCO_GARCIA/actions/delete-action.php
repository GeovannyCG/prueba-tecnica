<?php
try {
    //Importar el model
    require ('../model/board-model.php');

    //Crear la instancia del model
    $objModelB = new Dashboard_model();

    $id = $_GET['id'];

    $response = json_encode($objModelB->deleteUser($id));

    if ($response) {
        echo "<script>alert('Usuario " . $id . " eliminado'); window.location.href = '../Dashboard/';</script>";
    }
} catch (\Throwable $th) {
    echo "<script>alert('Usuario no encontrado'); window.location.href = '../Dashboard/';</script>";
}