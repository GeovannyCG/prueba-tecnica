-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-07-2024 a las 13:16:03
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dbprueba`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `informacion_personal`
--

CREATE TABLE `informacion_personal` (
  `id_ip` int(11) NOT NULL,
  `adress_ip` varchar(100) NOT NULL,
  `phone_ip` bigint(255) NOT NULL,
  `birthday_ip` date NOT NULL,
  `id_a` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `informacion_personal`
--

INSERT INTO `informacion_personal` (`id_ip`, `adress_ip`, `phone_ip`, `birthday_ip`, `id_a`) VALUES
(226, 'Calle Falsa 123, Ciudad Ejemplo', 6001234511, '1990-01-01', 31),
(227, 'Avenida Siempre Viva 742, Springfield', 6002345678, '1991-02-02', 32),
(228, 'Calle Principal 456, Pueblo Nuevo', 6003456789, '1992-03-03', 33),
(229, 'Carrera Central 789, Villa Alegría', 6004567890, '1993-04-04', 34),
(230, 'Plaza Mayor 101, Ciudad Vieja', 6005678901, '1994-05-05', 35),
(231, 'Calle Secundaria 202, Barrio Norte', 6006789012, '1995-06-06', 36),
(232, 'Avenida del Sol 303, Villa Luz', 6007890123, '1996-07-07', 37),
(233, 'Calle Luna 404, Ciudad Jardín', 6008901234, '1997-08-08', 38),
(234, 'Boulevard Estrella 505, Pueblo Unido', 6019012345, '1998-09-09', 39),
(235, 'Calle Primavera 606, Villa Verde', 6020123456, '1999-10-10', 40),
(236, 'Calle Otoño 707, Ciudad Nueva', 6031234567, '1990-11-11', 41),
(237, 'Avenida Invierno 808, Pueblo Libre', 6042345678, '1991-12-12', 42),
(238, 'Calle Verano 909, Villa Rosa', 6053456789, '1992-01-13', 43),
(239, 'Avenida del Mar 111, Ciudad Azul', 6064567890, '1993-02-14', 44),
(240, 'Calle Rio 222, Pueblo Blanco', 6075678901, '1994-03-15', 45),
(241, 'Carrera del Bosque 333, Villa Oro', 6086789012, '1995-04-16', 46),
(242, 'Calle Laguna 444, Ciudad Plata', 6097890123, '1996-05-17', 47),
(243, 'Avenida del Parque 555, Pueblo Gris', 6108901234, '1997-06-18', 48),
(244, 'Calle Montaña 666, Villa Blanca', 6119012345, '1998-07-19', 49),
(245, 'Boulevard del Lago 777, Ciudad Negra', 6120123456, '1999-08-20', 50),
(246, 'Calle Bosque 888, Pueblo Verde', 6131234567, '1990-09-21', 51),
(247, 'Avenida del Valle 999, Villa Marrón', 6142345678, '1991-10-22', 52),
(248, 'Calle del Campo 1010, Ciudad Dorada', 6153456789, '1992-11-23', 53),
(249, 'Carrera del Río 1111, Pueblo Plateado', 6164567890, '1993-12-24', 54),
(250, 'Calle del Sol 1212, Villa Cristal', 6175678901, '1994-01-25', 55),
(251, 'Avenida del Cielo 1313, Ciudad Esmeralda', 6186789012, '1995-02-26', 56),
(252, 'Calle del Viento 1414, Pueblo Diamante', 6197890123, '1996-03-27', 57),
(253, 'Carrera del Norte 1515, Villa Rubí', 6208901234, '1997-04-28', 58),
(254, 'Calle del Sur 1616, Ciudad Zafiro', 6219012345, '1998-05-29', 59),
(255, 'Boulevard del Este 1717, Pueblo Jade', 6220123456, '1999-06-30', 60),
(256, 'Calle del Oeste 1818, Villa Turquesa', 6231234567, '1990-07-31', 61),
(257, 'Avenida del Centro 1919, Ciudad Coral', 6242345678, '1991-08-01', 62),
(258, 'Calle del Rey 2020, Pueblo Granate', 6253456789, '1992-09-02', 63),
(259, 'Carrera de la Reina 2121, Villa Amatista', 6264567890, '1993-10-03', 64),
(260, 'Calle del Príncipe 2222, Ciudad Perla', 6275678901, '1994-11-04', 65),
(261, 'Avenida de la Princesa 2323, Pueblo Topacio', 6286789012, '1995-12-05', 66),
(262, 'Calle del Duque 2424, Villa Opalo', 6297890123, '1996-01-06', 67),
(263, 'Carrera de la Duquesa 2525, Ciudad Onix', 6308901234, '1997-02-07', 68),
(264, 'Calle del Barón 2626, Pueblo Esmeralda', 6319012345, '1998-03-08', 69),
(265, 'Boulevard de la Baronesa 2727, Villa Coral', 6320123456, '1999-04-09', 70),
(266, 'Calle del Conde 2828, Ciudad Diamante', 6331234567, '1990-05-10', 71),
(267, 'Avenida de la Condesa 2929, Pueblo Rubí', 6342345678, '1991-06-11', 72),
(268, 'Calle del Vizconde 3030, Villa Jade', 6353456789, '1992-07-12', 73),
(269, 'Carrera de la Vizcondesa 3131, Ciudad Zafiro', 6364567890, '1993-08-13', 74),
(270, 'Calle del Marqués 3232, Pueblo Granate', 6375678901, '1994-09-14', 75),
(271, 'Avenida de la Marquesa 3333, Villa Topacio', 6386789012, '1995-10-15', 76),
(272, 'Calle del Duque 3434, Ciudad Amatista', 6397890123, '1996-11-16', 77),
(273, 'Carrera del Marqués 3535, Pueblo Onix', 6408901234, '1997-12-17', 78),
(274, 'Calle del Barón 3636, Villa Perla', 6419012345, '1998-01-18', 79),
(275, 'Boulevard de la Baronesa 3737, Ciudad Coral', 6420123456, '1999-02-19', 80),
(276, 'Calle del Conde 3838, Pueblo Rubí', 6431234567, '1990-03-20', 81),
(277, 'Avenida de la Condesa 3939, Villa Jade', 6442345678, '1991-04-21', 82),
(278, 'Calle del Vizconde 4040, Ciudad Zafiro', 6453456789, '1992-05-22', 83),
(279, 'Carrera de la Vizcondesa 4141, Pueblo Granate', 6464567890, '1993-06-23', 84),
(280, 'Calle del Marqués 4242, Villa Topacio', 6475678901, '1994-07-24', 85),
(281, 'Avenida de la Marquesa 4343, Ciudad Amatista', 6486789012, '1995-08-25', 86),
(282, 'Calle del Duque 4444, Pueblo Onix', 6497890123, '1996-09-26', 87),
(283, 'Carrera del Marqués 4545, Villa Perla', 6508901234, '1997-10-27', 88),
(284, 'Calle del Barón 4646, Ciudad Coral', 6519012345, '1998-11-28', 89),
(285, 'Boulevard de la Baronesa 4747, Pueblo Rubí', 6520123456, '1999-12-29', 90),
(286, 'Calle del Conde 4848, Villa Jade', 6531234567, '1990-01-30', 91),
(287, 'Avenida de la Condesa 4949, Ciudad Zafiro', 6542345678, '1991-02-01', 92),
(288, 'Calle del Vizconde 5050, Pueblo Granate', 6553456789, '1992-03-02', 93),
(289, 'Carrera de la Vizcondesa 5151, Villa Topacio', 6564567890, '1993-04-03', 94),
(290, 'Calle del Marqués 5252, Ciudad Amatista', 6575678901, '1994-05-04', 95),
(291, 'Avenida de la Marquesa 5353, Pueblo Onix', 6586789012, '1995-06-05', 96),
(292, 'Calle del Duque 5454, Villa Perla', 6597890123, '1996-07-06', 97),
(293, 'Carrera del Marqués 5555, Ciudad Coral', 6608901234, '1997-08-07', 98),
(294, 'Calle del Barón 5656, Pueblo Rubí', 6619012345, '1998-09-08', 99),
(295, 'Boulevard de la Baronesa 5757, Villa Jade', 6620123456, '1999-10-09', 100),
(296, 'Calle del Conde 5858, Ciudad Zafiro', 6631234567, '1990-11-10', 101),
(297, 'Avenida de la Condesa 5959, Pueblo Granate', 6642345678, '1991-12-11', 102),
(298, 'Calle del Vizconde 6060, Villa Topacio', 6653456789, '1992-01-12', 103),
(299, 'Carrera de la Vizcondesa 6161, Ciudad Amatista', 6664567890, '1993-02-13', 104),
(300, 'Calle del Marqués 6262, Pueblo Onix', 6675678901, '1994-03-14', 105),
(301, 'Avenida de la Marquesa 6363, Villa Perla', 6686789012, '1995-04-15', 106),
(302, 'Calle del Duque 6464, Ciudad Coral', 6697890123, '1996-05-16', 107),
(303, 'Carrera del Marqués 6565, Pueblo Rubí', 6708901234, '1997-06-17', 108),
(304, 'Calle del Barón 6666, Villa Jade', 6719012345, '1998-07-18', 109),
(305, 'Boulevard de la Baronesa 6767, Ciudad Zafiro', 6720123456, '1999-08-19', 110),
(306, 'Calle del Conde 6868, Pueblo Granate', 6731234567, '1990-09-20', 111),
(307, 'Avenida de la Condesa 6969, Villa Topacio', 6742345678, '1991-10-21', 112),
(308, 'Calle del Vizconde 7070, Ciudad Amatista', 6753456789, '1992-11-22', 113),
(309, 'Carrera de la Vizcondesa 7171, Pueblo Onix', 6764567890, '1993-12-23', 114),
(310, 'Calle del Marqués 7272, Villa Perla', 6775678901, '1994-01-24', 115),
(311, 'Avenida de la Marquesa 7373, Ciudad Coral', 6786789012, '1995-02-25', 116),
(312, 'Calle del Duque 7474, Pueblo Rubí', 6797890123, '1996-03-26', 117),
(313, 'Carrera del Marqués 7575, Villa Jade', 6808901234, '1997-04-27', 118),
(314, 'Calle del Barón 7676, Ciudad Zafiro', 6819012345, '1998-05-28', 119),
(315, 'Boulevard de la Baronesa 7777, Pueblo Granate', 6820123456, '1999-06-29', 120),
(316, 'Calle del Conde 7878, Villa Topacio', 6831234567, '1990-07-30', 121),
(317, 'Avenida de la Condesa 7979, Ciudad Amatista', 6842345678, '1991-08-31', 122),
(318, 'Calle del Vizconde 8080, Pueblo Onix', 6853456789, '1992-09-01', 123),
(319, 'Carrera de la Vizcondesa 8181, Villa Perla', 6864567890, '1993-10-02', 124),
(320, 'Calle del Marqués 8282, Ciudad Coral', 6875678901, '1994-11-03', 125);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_a` int(11) NOT NULL,
  `name_a` varchar(100) NOT NULL,
  `email_a` varchar(100) NOT NULL,
  `password_a` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_a`, `name_a`, `email_a`, `password_a`) VALUES
(31, 'Juan Pérez', 'juan.perez@example.com', 'password123'),
(32, 'María García', 'maria.garcia@example.com', 'password123'),
(33, 'Carlos López', 'carlos.lopez@example.com', 'password123'),
(34, 'Ana Martínez', 'ana.martinez@example.com', 'password123'),
(35, 'Luis Fernández', 'luis.fernandez@example.com', 'password123'),
(36, 'Marta Sánchez', 'marta.sanchez@example.com', 'password123'),
(37, 'José Díaz', 'jose.diaz@example.com', 'password123'),
(38, 'Laura Gómez', 'laura.gomez@example.com', 'password123'),
(39, 'David Ruiz', 'david.ruiz@example.com', 'password123'),
(40, 'Sofía Jiménez', 'sofia.jimenez@example.com', 'password123'),
(41, 'Jorge Morales', 'jorge.morales@example.com', 'password123'),
(42, 'Elena Ortiz', 'elena.ortiz@example.com', 'password123'),
(43, 'Fernando Ramírez', 'fernando.ramirez@example.com', 'password123'),
(44, 'Carmen Torres', 'carmen.torres@example.com', 'password123'),
(45, 'Ricardo Gutiérrez', 'ricardo.gutierrez@example.com', 'password123'),
(46, 'Lucía Rojas', 'lucia.rojas@example.com', 'password123'),
(47, 'Manuel Castro', 'manuel.castro@example.com', 'password123'),
(48, 'Patricia Mendoza', 'patricia.mendoza@example.com', 'password123'),
(49, 'Alberto Romero', 'alberto.romero@example.com', 'password123'),
(50, 'Gloria Hernández', 'gloria.hernandez@example.com', 'password123'),
(51, 'Francisco Navarro', 'francisco.navarro@example.com', 'password123'),
(52, 'Isabel Vargas', 'isabel.vargas@example.com', 'password123'),
(53, 'Miguel Herrera', 'miguel.herrera@example.com', 'password123'),
(54, 'Pilar Medina', 'pilar.medina@example.com', 'password123'),
(55, 'Sergio Castro', 'sergio.castro@example.com', 'password123'),
(56, 'Teresa Delgado', 'teresa.delgado@example.com', 'password123'),
(57, 'Raúl Silva', 'raul.silva@example.com', 'password123'),
(58, 'Nuria Ramos', 'nuria.ramos@example.com', 'password123'),
(59, 'Pedro Cruz', 'pedro.cruz@example.com', 'password123'),
(60, 'Silvia Ortega', 'silvia.ortega@example.com', 'password123'),
(61, 'Antonio Peña', 'antonio.pena@example.com', 'password123'),
(62, 'Rosa Soto', 'rosa.soto@example.com', 'password123'),
(63, 'Julio Torres', 'julio.torres@example.com', 'password123'),
(64, 'Clara Molina', 'clara.molina@example.com', 'password123'),
(65, 'Alejandro Cabrera', 'alejandro.cabrera@example.com', 'password123'),
(66, 'Beatriz Castro', 'beatriz.castro@example.com', 'password123'),
(67, 'Andrés Guerrero', 'andres.guerrero@example.com', 'password123'),
(68, 'Celia Guzmán', 'celia.guzman@example.com', 'password123'),
(69, 'Enrique Reyes', 'enrique.reyes@example.com', 'password123'),
(70, 'Paloma Moreno', 'paloma.moreno@example.com', 'password123'),
(71, 'Vicente Peña', 'vicente.pena@example.com', 'password123'),
(72, 'Alicia Muñoz', 'alicia.munoz@example.com', 'password123'),
(73, 'Rafael Sánchez', 'rafael.sanchez@example.com', 'password123'),
(74, 'Natalia Ortiz', 'natalia.ortiz@example.com', 'password123'),
(75, 'Adrián Gutiérrez', 'adrian.gutierrez@example.com', 'password123'),
(76, 'Yolanda Ramos', 'yolanda.ramos@example.com', 'password123'),
(77, 'Alfonso Torres', 'alfonso.torres@example.com', 'password123'),
(78, 'Lorena Mendoza', 'lorena.mendoza@example.com', 'password123'),
(79, 'Daniel Morales', 'daniel.morales@example.com', 'password123'),
(80, 'Carmen Sánchez', 'carmen.sanchez@example.com', 'password123'),
(81, 'José García', 'jose.garcia@example.com', 'password123'),
(82, 'Marta Fernández', 'marta.fernandez@example.com', 'password123'),
(83, 'Carlos López', 'carlos.lopez@example.com', 'password123'),
(84, 'Ana Martínez', 'ana.martinez@example.com', 'password123'),
(85, 'Luis Rodríguez', 'luis.rodriguez@example.com', 'password123'),
(86, 'Mónica Jiménez', 'monica.jimenez@example.com', 'password123'),
(87, 'Alberto Herrera', 'alberto.herrera@example.com', 'password123'),
(88, 'Patricia Gómez', 'patricia.gomez@example.com', 'password123'),
(89, 'Miguel Fernández', 'miguel.fernandez@example.com', 'password123'),
(90, 'Raquel González', 'raquel.gonzalez@example.com', 'password123'),
(91, 'Javier García', 'javier.garcia@example.com', 'password123'),
(92, 'Laura López', 'laura.lopez@example.com', 'password123'),
(93, 'Andrés Pérez', 'andres.perez@example.com', 'password123'),
(94, 'Beatriz Sánchez', 'beatriz.sanchez@example.com', 'password123'),
(95, 'Daniela Torres', 'daniela.torres@example.com', 'password123'),
(96, 'Santiago Morales', 'santiago.morales@example.com', 'password123'),
(97, 'Clara Ruiz', 'clara.ruiz@example.com', 'password123'),
(98, 'Julio Gómez', 'julio.gomez@example.com', 'password123'),
(99, 'Carolina Ortega', 'carolina.ortega@example.com', 'password123'),
(100, 'Francisco Castro', 'francisco.castro@example.com', 'password123'),
(101, 'Silvia Ramos', 'silvia.ramos@example.com', 'password123'),
(102, 'Fernando Mendoza', 'fernando.mendoza@example.com', 'password123'),
(103, 'Gloria Pérez', 'gloria.perez@example.com', 'password123'),
(104, 'Alejandro Ortiz', 'alejandro.ortiz@example.com', 'password123'),
(105, 'Lucía Fernández', 'lucia.fernandez@example.com', 'password123'),
(106, 'Antonio Rodríguez', 'antonio.rodriguez@example.com', 'password123'),
(107, 'Isabel Gutiérrez', 'isabel.gutierrez@example.com', 'password123'),
(108, 'José Martínez', 'jose.martinez@example.com', 'password123'),
(109, 'Marta Jiménez', 'marta.jimenez@example.com', 'password123'),
(110, 'Luis Gómez', 'luis.gomez@example.com', 'password123'),
(111, 'Elena López', 'elena.lopez@example.com', 'password123'),
(112, 'Carlos Sánchez', 'carlos.sanchez@example.com', 'password123'),
(113, 'Ana García', 'ana.garcia@example.com', 'password123'),
(114, 'Sergio Fernández', 'sergio.fernandez@example.com', 'password123'),
(115, 'Teresa Herrera', 'teresa.herrera@example.com', 'password123'),
(116, 'Raúl González', 'raul.gonzalez@example.com', 'password123'),
(117, 'Pilar Gómez', 'pilar.gomez@example.com', 'password123'),
(118, 'Manuel López', 'manuel.lopez@example.com', 'password123'),
(119, 'Patricia García', 'patricia.garcia@example.com', 'password123'),
(120, 'David Rodríguez', 'david.rodriguez@example.com', 'password123'),
(121, 'Sofía Martínez', 'sofia.martinez@example.com', 'password123'),
(122, 'Jorge Jiménez', 'jorge.jimenez@example.com', 'password123'),
(123, 'Lucía Sánchez', 'lucia.sanchez@example.com', 'password123'),
(124, 'José Pérez', 'jose.perez@example.com', 'password123'),
(125, 'Marta Fernández', 'marta.fernandez@example.com', 'password123');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `informacion_personal`
--
ALTER TABLE `informacion_personal`
  ADD PRIMARY KEY (`id_ip`),
  ADD KEY `id_a` (`id_a`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_a`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `informacion_personal`
--
ALTER TABLE `informacion_personal`
  MODIFY `id_ip` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=321;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_a` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `informacion_personal`
--
ALTER TABLE `informacion_personal`
  ADD CONSTRAINT `informacion_personal_ibfk_1` FOREIGN KEY (`id_a`) REFERENCES `usuarios` (`id_a`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
