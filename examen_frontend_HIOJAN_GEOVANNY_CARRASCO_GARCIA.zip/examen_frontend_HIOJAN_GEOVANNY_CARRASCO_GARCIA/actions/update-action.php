<?php
try {
    //Importar el model
    require ('../model/edit-model.php');

    //Crear la instancia del model
    $objModelE = new Edit_model();

    //Obtener los datos del formulario
    $id = $_GET['id'];
    $name = $_POST['inputName'];
    $email = $_POST['inputEmail']; 
    $pass = $_POST['inputPass']; 
    $address = $_POST['inputAdress'];
    $phone = $_POST['inputNumber'];
    $birthday = $_POST['inputBirthday'];

    //Crear el array que sera enviado para la API
    $data = array(
        "id" => $id,
        "name" => $name, 
        "email" => $email, 
        "password" => $pass, 
        "adress" => $address, 
        "phone" => $phone,
        "birthday" => $birthday
    );

    $response = json_encode($objModelE->UpdateUser($data));

    if ($response) {
        echo "<script>alert('Usuario actualizado'); window.location.href = '../Dashboard/';</script>";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}