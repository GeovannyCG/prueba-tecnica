<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar usuario - Prueba Tecnica</title>
    <!-- link de CSS Local -->
    <link rel="stylesheet" type="text/css" href="../assets/css/edit-style.css">
    <!-- link de CDN CSS de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- link de CDN icons Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>

<body>
    <!-- Start Navbar -->
    <nav class="navbar fixed-top" id="nav-main">
        <div class="container-fluid">
            <a class="navbar-brand" href="../Dashboard/">
                <img src="../assets/images/logo.png" alt="Logo" width="30" height="24"
                    class="d-inline-block align-text-top">
                Prueba Tecnica
            </a>
        </div>
    </nav>

    <nav aria-label="breadcrumb" style="padding: 10px; margin-top: 60px;">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="../Dashboard/">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">EditUser</li>
        </ol>
    </nav>

    <!-- End Navbar -->

    <main>
        <div id="form-container">
            <h2>Editar usuario</h2>

            <!-- Campo para el Id -->
            <form action="../Update/<?php echo $datos[0]["id_a"] ?>" method="post" onsubmit="return validateForm()">

                <!-- Campo para el Nombre -->
                <div class="mb-3">
                    <label for="inputName" class="form-label">Nombre completo</label>
                    <input type="text" class="form-control" value="<?php echo $datos[0]["name_a"] ?>" name="inputName"
                        id="inputName" placeholder="Introduce tu nombre completo" required>
                </div>

                <!-- Campo para el correo -->
                <div class="mb-3">
                    <label for="inputEmail" class="form-label">Correo electronico</label>
                    <input type="email" class="form-control" value="<?php echo $datos[0]["email_a"] ?>"
                        name="inputEmail" id="inputEmail" placeholder="name@example.com" required>
                </div>

                <!-- Campo para la contra -->
                <div class="mb-3">
                    <label for="inputPass" class="form-label">Contraseña</label>
                    <input type="text" class="form-control" value="<?php echo $datos[0]["password_a"] ?>"
                        name="inputPass" id="inputPass" required>
                </div>

                <!-- Campo para la direccion -->
                <div class="mb-3">
                    <label for="inputAdress" class="form-label">Direccion</label>
                    <input type="texto" class="form-control" value="<?php echo $datos[0]["adress_ip"] ?>"
                        name="inputAdress" id="inputAdress" placeholder="Calle siempre viva, Numero 4." required>
                </div>

                <!-- Campo para el telefono -->
                <div class="mb-3">
                    <label for="inputNumber" class="form-label">Telefono</label>
                    <input type="number" class="form-control" value="<?php echo $datos[0]["phone_ip"] ?>"
                        name="inputNumber" id="inputNumber" placeholder="5566778899" required>
                </div>

                <!-- Campo para la fecha de nacimiento -->
                <div class="mb-3">
                    <label for="inputBirthday" class="form-label">Fecha de nacimiento</label>
                    <input type="date" class="form-control"
                        value="<?php echo date('Y-m-d', strtotime($datos[0]["birthday_ip"])); ?>" name="inputBirthday"
                        id="inputBirthday" required>
                </div>

                <!-- boton para el submit -->
                <button type="submit" class="btn btn-success"><i class="bi bi-arrow-clockwise"></i> Actualizar</button>
            </form>

        </div>
    </main>



    <!-- link de CDN JavaScript de bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <!-- Link de Java script propio -->
    <script src="../assets/js/edit-app.js"></script>
</body>

</html>