// Importamos los módulos necesarios
const express = require('express');
const mysql = require('mysql2');
const myconn = require('express-myconnection');

// Importamos las rutas definidas en otro archivo
const routes = require("./routes");

// Inicializamos la aplicación Express y la asignamos a una constante 'app'
const app = express();

// Configuramos el puerto en el que la aplicación va a escuchar las solicitudes
const port = process.env.PORT || 9000;
app.set('port', port);

// Configuración de las credenciales de la base de datos MySQL
const dbCredentials = {
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: '',
    database: 'dbprueba'
};

// Middlewares ---------------------------

// Middleware para conectar Express con MySQL utilizando express-myconnection
app.use(myconn(mysql, dbCredentials, 'single'));

// Middleware para permitir a Express procesar datos JSON en las solicitudes HTTP
app.use(express.json());

// Ruta de prueba para verificar que el servidor está funcionando
app.get('/', (req, res) => {
    res.send("Hello World!");
});

// Rutas definidas en el archivo 'routes' para la API
app.use('/api', routes);

// Función para intentar iniciar el servidor en el puerto dado
function startServer(port) {
    app.listen(port, () => {
        console.log(`Servidor ejecutándose en puerto: ${port}`);
    }).on('error', (err) => {
        if (err.code === 'EADDRINUSE') { // Error si el puerto está en uso
            console.log(`El puerto ${port} está ocupado, intentando el siguiente...`);
            startServer(port + 1); // Intenta con el siguiente puerto
        } else {
            console.error(err); // Otro tipo de error
        }
    });
}

// Iniciar el servidor
startServer(port);